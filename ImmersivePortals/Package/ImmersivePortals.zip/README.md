Immersive Portals
A BepInEx mod for Valheim. Removes the loading sceen from portals entirely and renders the destination onto the entry portal.

:: REQUIREMENTS ::
• BepInEx

:: FEATURES ::
• Instantaneous teleportation.

:: GENERAL OTHER STUFF ::
• Clean code crafted to be as compatible as possible.

:: CREDITS ::
♦ Nekres

# ImmersivePortals for Valheim

This is a Bepinex mod for Valheim that .

## Installation (manual)

If you are installing this manually, do the following

1. Extract the archive into a folder. **Do not extract into the game folder.**
2. Move the contents of `plugins` folder into `<GameDirectory>\Bepinex\plugins`.
3. Run the game.
